/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.example.tutorial02ex2;
import java.util.ArrayList;
import java.util.List;
// UserValidator.java
public class UserValidator {
    public static boolean isValidAge(int age) {
        return age > 0;
    }
    // Add other validation methods as needed
}







